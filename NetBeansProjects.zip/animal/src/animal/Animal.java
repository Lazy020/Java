package animal;

    public class Animal {
     public String emiteSom() {
     return "qualquer som";
   }
    static public class gato extends Animal{
    public String emiteSom(){
      return "miauu";
    }
    }
    static public class galinha extends Animal{
    public String emiteSom(){
    return "po po";
  }
    }
    static  public class cachorro extends Animal {
    public String emiteSom(){
     return "auaua";
   }
  
    }
    public static void main(String[] args) {
    Animal a1 = new Animal();
    cachorro J = new cachorro();
    gato jef = new gato();
    galinha a = new galinha();
    
    System.out.println("O som do animal é: " + a1.emiteSom());
    System.out.println("O som do cachorro é: " + J.emiteSom());
    System.out.println("O som do gato é: " + jef.emiteSom());
    System.out.println("O som da galinha é: " + a.emiteSom());
}
    }

    