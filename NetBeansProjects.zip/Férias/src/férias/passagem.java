package férias;


public class passagem {
   private double valor, imposto, seguro;

   public double calcularPreco(double valor, double imposto) {
     this.valor = valor;
     this.imposto = imposto;
     return this.valor + this.imposto;
  }
   
   public double calcularPrecoo(double valor, double imposto, double seguro) {
     return this.valor + this.imposto + this.seguro;
     
   }

}

  
