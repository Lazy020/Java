
package férias;


public class Férias {


    public static void main(String[] args) {
    passagem p1 = new passagem();
    System.out.println("O valor da passagem sem seguro é: " + p1.calcularPreco(100,10));
    System.out.println("O valor da passagem com seguro é:  " + p1.calcularPrecoo(100, 10, 20));
    }
    
    
}
