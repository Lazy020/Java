package trabalhos;

public class Pessoa {
 private String nome;
 private double idade, peso, altura;


  public Pessoa(String n , double i, double p, double a) {
   this.nome = n;
   this.idade = i;
   this.peso = p;
   this.altura = a;
  }
  public String dizerNome(){
   return this.nome;
  }
  public double envelhecer(double i){
     this.idade += i;
     if (this.idade < 21) 
        this.altura = this.altura + 0.5;
     return this.idade;  
  }
  
   public double engordar(double p){
     this.peso += p;
     return this.peso;  
   }
   
   public double emagrecer(double p) {
     this.peso -= p;
     return this.peso;
   }
   
   public double crescer(double a) {
     this.altura += a;
     return this.altura;
   }
}

