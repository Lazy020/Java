package trabalhos;


public class Tv {
 private int canal, volume;


  public Tv(int c, int v) {
   this.canal = c;
   this.volume = v;
}
  public int nrCanal() {
    return this.canal;
 }
  public void mudarCanal(int c){
    this.canal = c;
  }
  public int volume(){
    return this.volume;
  }
  public int aumentarVolume(int v) {
    if (this.volume != 10){
          this.volume = volume + 1; 
          
    }else{
         this.volume = 10;
    }
    return this.volume;
  }
  public int diminuirVolume (int v) {
     if (this.volume != 10) {
          this.volume = volume - 1;
    
     }else{
          this.volume = 10;
     }
     return this.volume;
  }
 
}
 
