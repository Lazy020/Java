package trabalhos;

public class Quadrado {
  private double tamanhodolado;
  
  
  public Quadrado (double l){
   this.tamanhodolado = l;
  
  }
  
  public void mudar_lado(double l) {
   this.tamanhodolado = l;
  }
  
  public double retornar_lado() {
   return this.tamanhodolado;
  }
  
  public double calcular_area() {
   return this.tamanhodolado * this.tamanhodolado;
  }
}  

