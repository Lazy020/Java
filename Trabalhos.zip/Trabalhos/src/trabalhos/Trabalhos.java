package trabalhos;

public class Trabalhos {

public static void main(String[] args) {
     //ex1 
  Bola bolinha = new Bola("amarelo", "plastico", 45.2);
  System.out.println("A cor da bola é: " + bolinha.mostrarCor());
  bolinha.trocarCor("vermelho");
  System.out.println("A outra cor da bola é: " + bolinha.mostrarCor());     
    System.out.println("\n");
  //testando exe 2
  Quadrado tamanhodolado = new Quadrado(200); 
  System.out.println("O valor do lado é: " + tamanhodolado.retornar_lado());
  System.out.println("A área é: " + tamanhodolado.calcular_area());
  tamanhodolado.mudar_lado(150);
  System.out.println("O valor do outro lado é: " + tamanhodolado.retornar_lado());
  System.out.println("A área é: " + tamanhodolado.calcular_area()); 
    System.out.println("\n");
  
 //teste ex3
 Pessoa gente = new Pessoa("Clovis", 17, 70.4, 1.60);
 System.out.println("O nome da pessoa é: " + gente.dizerNome());
 System.out.println("A idade da pessoa é: " + gente.envelhecer(2));
 System.out.println("A altura da pessoa é: " + gente.crescer(0.5));
 System.out.println("O peso da pessoa é: " + gente.engordar(0.6));
 System.out.println("O peso que a pessoa se adequa é: " + gente.emagrecer(4));
   System.out.println("\n");
   
   
//teste ex4
 Tv controle = new Tv(30,70);
 System.out.println("O número do canal é: " + controle.nrCanal());
 System.out.println("O volume do canal é: " + controle.volume());
 controle.mudarCanal(20);
 System.out.println("O canal quando mudado é: " + controle.nrCanal());
 System.out.println("O canal quando aumentado é: " + controle.aumentarVolume(10));
 controle.diminuirVolume(10);
 System.out.println("O volume quando baixado é: " + controle.diminuirVolume(10));
}

}
